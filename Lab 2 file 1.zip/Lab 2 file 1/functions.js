// Define some functions
function function1() {
    console.log('Function 1 called');
  }
  
  function function2() {
    console.log('Function 2 called');
  }
  
  // Exporting the functions
  module.exports = {
    function1,
    function2
  };
  