// Importing the other JavaScript file (functions.js)
const { function1, function2 } = require('./functions');

// Calling/invoke a list of functions
function1();
function2();
