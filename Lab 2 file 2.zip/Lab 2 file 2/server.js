

// Importing the utilities file (functions.js)
const utils = require('./functions');


// Using the utility functions
utils.welcomeMessage('Jasmeen', 'Kaur');

const convertedValue = utils.convertUnits(25, 'Minutes');
console.log(`Converted value: ${convertedValue}`);

const factorialResult = utils.calculateFactorial(10);
console.log(`Factorial of 10: ${factorialResult}`);

const squareRootResult = utils.calculateSquareRoot(4);
console.log(`Square Root of 4: ${squareRootResult}`);
