// First Function: Concatenate Text
function welcomeMessage(firstName, lastName) {
    console.log(`Welcome ${firstName} ${lastName} to our home`);
  }
  
  // Second Function: Measurement Unit Conversion
  function convertUnits(value, initialUnit) {
    if (initialUnit === 'Celsius') {
      // Convert Celsius to Fahrenheit
      return (value * 9/5) + 32;
    } else if (initialUnit === 'Fahrenheit') {
      // Convert Fahrenheit to Celsius
      return (value - 32) * 5/9;
    } else if (initialUnit === 'Minutes') {
      // Convert Minutes to Hours
      return value / 60;
    } else if (initialUnit === 'Hours') {
      // Convert Hours to Minutes
      return value * 60;
    } else {
      throw new Error('Unsupported unit');
    }
  }
  
  // Third Function: Math Operation - Factorial
  function calculateFactorial(value) {
    if (value === 0 || value === 1) {
      return 1;
    } else {
      return value * calculateFactorial(value - 1);
    }
  }
  
  // Fourth Function: Advanced Function - Square Root using Math Library
  function calculateSquareRoot(value) {
    return Math.sqrt(value);
  }
  
  // Exporting the functions
  module.exports = {
    welcomeMessage,
    convertUnits,
    calculateFactorial,
    calculateSquareRoot
  };
  